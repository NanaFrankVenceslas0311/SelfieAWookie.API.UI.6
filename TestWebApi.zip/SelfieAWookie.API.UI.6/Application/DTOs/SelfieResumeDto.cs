﻿using System.Reflection;

namespace SelfieAWookie.API.UI._6.Application.DTOs
{
    public class SelfieResumeDto
    {
        #region Properties

        public int NbSelfiesFromWookie { get; set; }
        public string Title { get; set; }
        public int WookieId { get; set; }


        #endregion
    }
}
